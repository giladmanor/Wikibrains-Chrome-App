Wikibrains-Chrome-App
=====================

Chrome app for Wikibrains client
